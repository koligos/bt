%###########################################################
% Script to find number of N sensors with ID  in given area
%###########################################################

%% Initialization
clear all;
iterations = 30;
nodes=60;
G=graph(bucky); %generates  graph
L=full(laplacian(G));
degreeMax= max(max(L));
alpha=1/degreeMax;
P=eye(nodes)- alpha* L; %Perron matrix

for i = 1:nodes
x_running(1,i)=i; %initialization vertex with its ID
end
for i = 1:iterations
    x_running(1+i,:)=P*x_running(i,:)';
end

figure;
plot(0:iterations, x_running(:,:));
ttl1=title( 'Average ID number estimation'  )
ttl1=set(ttl1,'Interpreter','latex','FontSize', 15);
xlbl1=xlabel('Iterations [-]');
xlbl1=set(xlbl1,'Interpreter','latex');
ylbl1=ylabel('Node ID [-]');
ylbl1=set(ylbl1,'Interpreter','latex');
grid;

figure;
h = plot(G);
c = h.EdgeColor;
h.EdgeColor = 'k';
h.LineWidth=1
h.MarkerSize=8;
h.EdgeAlpha=1;
labelnode(h,1:nodes,' ')



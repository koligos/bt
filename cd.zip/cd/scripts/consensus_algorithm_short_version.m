clear all;
clc;
s=[1 1 2 2 3 3 3 4 4 4 5 6 7 8 8 9 9 10  ];%source vertices
t=[2 3 4 5 7 10 5 5 6 7 6 7 5 1 2 10 7 8];%destination vertices
w=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1]; %weights of edges
G = graph(s,t,w); %create graph G with parameters s, t, w
iterations = 199;

for i=1:10
x_0(i)=i;    %initialize measurement
end
x_estimate_running_basic(1,:) = x_0;

A=adjacency(G); %adjacency matrix
L=laplacian(G); %laplacian matrix

eig_L=eig(L);
alpha=2/(eig_L(2)+eig_L(10));%the best possible coefficient

P=eye(10)- alpha* L; %the Best Perron Matrix

for i=1:iterations
   x=P^i*x_0'; 
   x_estimate_running_basic(i+1,:)=x; %classical linear consensus without noise
end

plot(0:iterations, x_estimate_running_basic(:,:));





















